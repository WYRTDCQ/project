<?php
$servername = "bdm721868123.my3w.com";
$username = "bdm721868123";
$password = "ZhSoftware2019";
$dbname = "bdm721868123_db";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 


?>