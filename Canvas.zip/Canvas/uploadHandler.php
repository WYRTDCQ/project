<!DOCTYPE html>

<html>
<head>
	<title>Handle File Upload</title>
</head>
<body>
    <h1>File Upload Test</h1>
<?php

    require_once "Upload.php";
    $SID=$_REQUEST['SID'];
    $ID=$_REQUEST['ID'];
    $target_dir = "uploads/"; 
    

    try {
        // 以下来自微信群第三方文件：关于文件上传
        $upload = new Upload('file1');
        $origFileName = $upload->getOrigFileName();
        $fileExt = $upload->getFileExt();
        $fileSize = $upload->getFileSize();
        $mimeType = $upload->getMimeType();
		if(!is_dir($target_dir) && !mkdir($target_dir)){
			die("error creating folder $targer_dir"); 
		}
        $destFilePath = $target_dir .  $origFileName;
       
 
    
        //保存到数据库中
        session_start();
        require_once('DBDA.class.php');
        require_once('db_function.php');
        $dbda = new DBDA();
        $course=sql_query("select * from course where ID={$ID}");
        $max=sql_query("select max(week) from asstea where ID={$ID}");
       // $where=array('ID'=> $count[0]['count(*)'], 'route'=>$dest,'label'=>0);//学生的作业编号为0
        $result = sql_query("select * from assignment where ID={$ID} and week={$max[0]['max(week)']} and SID={$SID}");    ///修改week！！！！！！！！！！！！！！！！！！！！！max  assignments
        if(count($result) > 0)
            $dbda->query("update assignment set file = '{$destFilePath}' where ID={$ID} and week={$max[0]['max(week)']} and SID={$SID}",0);
        else
            $dbda->query("insert into assignment values({$ID},{$max[0]['max(week)']},{$SID},'{$destFilePath}',0)",0);
        // Move that file to the destination
        $upload->moveFile($destFilePath);

        ?><script language="JavaScript">;alert("submit successfully!");location.href="assignments.php?ID=<?php echo $ID ?>&SID=<?php echo $SID ?>";</script>; <?php
        // Provide a link to that destination
       

        // If that file was a jpg or gif image, print an image tag displaying that file
        if ($fileExt == 'jpg' || $fileExt == 'gif' || $fileExt == 'png') {
            print "<p><img src='$destFilePath' alt='uploaded image'></p>\n";
        }

    } catch (UploadExceptionNoFile $e) {
        print "No file was uploaded.<br>\n";
    } catch (UploadException $e) {
        $code = $e->getCode();
        $message = $e->getMessage();
        print "Error: $message (code=$code)<br>\n";
    }
?>
</body>
</html>