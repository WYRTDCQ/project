<?php
//以下来自网上代码
function getExt($filename){
    return strtolower(pathinfo($filename,PATHINFO_EXTENSION));
}
?>