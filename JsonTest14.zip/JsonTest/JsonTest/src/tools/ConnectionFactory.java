package tools;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Driver;
import com.mysql.jdbc.Statement;

public class ConnectionFactory {
	private Connection connection;
	public Connection getConnection(String uname, String pwd) throws ClassNotFoundException,SQLException {
		
		DriverManager.registerDriver(new Driver());
		Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/dsd",  "root", "root");
		return connection;
	}
	public void closeConnection(Statement statement, Connection connection) {
		try {
			if(statement!=null) {
				statement.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(connection!=null) {
					try {
						connection.close();
					}
					catch(SQLException e){	
						
					}
			}
		}
	}
	public void closeConnection() {
		if(connection!=null) {
			try {
				connection.close();
			}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		} 
	}
}
