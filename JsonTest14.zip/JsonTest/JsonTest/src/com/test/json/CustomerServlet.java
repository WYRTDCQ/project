package com.test.json;

import java.io.*;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.google.gson.Gson;
import com.sun.*;
import com.test.model.BIDandRID;
import com.test.model.BuildingModel;
import com.test.model.ClientModel;
import com.test.model.BuildingTotal;
import com.test.model.ClientModel;
import com.test.model.LightModel;
import com.test.model.LightTotal;
import com.test.model.RoomModel;
import com.test.model.RoomTotal;
import com.test.model.SensorModel;
import com.test.model.SensorTotal;
import com.test.model.inputHardware;
import com.test.model.inputhardwareInfo;
import com.test.model.inputlogin;
import com.test.model.inputroom;
import com.test.model.inputuserInfo;
import com.test.model.outputHardware;
import com.test.model.outputdeviceinfo;
import com.test.model.outputhardwareinfo;
import com.test.model.outputlogin;
import com.test.model.outputroom;
import com.test.model.outputuserInfo;
import com.test.model.success;
import com.test.service.BuildingService;
import com.test.service.ClientService;
import com.test.service.ClientService;
import com.test.service.LightService;
import com.test.service.RoomService;
import com.test.service.SensorService;

import net.sf.json.JSONObject;
public class CustomerServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    String methodName2;
    JsonReader jr=new JsonReader();
    pack pk=new pack();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	this.doGet(request, response); 
    }
    private void test(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String a="success!";
    	Gson gson2 = new Gson();  
        String json = gson2.toJson(a);  
        pk.getpack(json, response);
    }
    private void user_login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
    	Gson gson = new Gson();
    	inputlogin t=new inputlogin();
    	t.UID=Integer.parseInt(request.getParameter("UID"));
    	t.password=request.getParameter("password");
    	System.out.println("HID:"+t.UID);
    	System.out.println("HID:"+t.password);
    	//JSONObject js=jr.receivePost(request);
    	//String str = gson.toJson(js);
    	// t = gson.fromJson(str, inputlogin.class);
    	ClientService clientservice =new ClientService ();
    	//t.UID=8;
    	//t.password="1234";
    	int s = 0 ;
		try {
			s = clientservice.loginAuthentication(t.getUID(),t.getpassword());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ClientModel c=new ClientModel();
		if(s==0) {
			c= clientservice.queryClient(t.getUID());
		}
		outputlogin output = new outputlogin(s,c);  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
    
    }
    
    
    
    private void server_Device (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int st=0;
    	Gson gson = new Gson();
    	inputHardware t=new inputHardware();	
    	t.BID=Integer.parseInt(request.getParameter("BID"));
    	t.RID=Integer.parseInt(request.getParameter("RID"));
    	//t.BID=1;t.RID=2;
    	LightService lightservice =new LightService ();
    	List<LightModel> lightlist = new ArrayList<LightModel>(); 
          try {
  			lightlist= lightservice.queryLightInARoom(t.BID,t.RID);
  		} catch (ClassNotFoundException | SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
          List<String>  info = new ArrayList<String>();
          if(lightlist.size()==0) {st=5;}
          for( int i=0; i<lightlist.size(); i++){
              info.add(lightlist.get(i).getLID());
          }
          outputHardware output = new outputHardware(st,info);  
          
          // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
          Gson gson2 = new Gson();  
          String json = gson2.toJson(output);  
          pk.getpack(json, response);
    }
    private void server_Sensor (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int st=0;
    	Gson gson = new Gson();
    	inputHardware t=new inputHardware();	
    	t.BID=Integer.parseInt(request.getParameter("BID"));
    	t.RID=Integer.parseInt(request.getParameter("RID"));
    	System.out.println("BID:"+t.BID);
    	System.out.println("RID:"+t.RID);
    	//t.BID=1;t.RID=2;
    	SensorService sensorservice =new SensorService ();
    	List<SensorModel> sensorlist = new ArrayList<SensorModel>(); 
          try {
  			sensorlist= sensorservice.querySensorInARoom(t.BID,t.RID);
  		} catch (ClassNotFoundException | SQLException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
          List<String>  info = new ArrayList<String>();
          if(sensorlist.size()==0) {st=5;}
          for( int i=0; i<sensorlist.size(); i++){
              info.add(sensorlist.get(i).getSID());
          }
          outputHardware output = new outputHardware(st,info);  
          
          // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
          Gson gson2 = new Gson();  
          String json = gson2.toJson(output);  
          pk.getpack(json, response);
    }

    
    private void server_room(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	inputroom t=new inputroom();
    	t.HID="S1";
    	t.HID=request.getParameter("HID");
    	System.out.println("ABC:"+t.HID);
    	RoomService roomservice =new RoomService ();  
    	if(t.HID.equals("0")) {
    		System.out.println("ZZZZ");
    	    	List<RoomModel> roomlist = new ArrayList<RoomModel>(); 
    	           try {
    	   			roomlist= roomservice.listAllRooms();
    	   		} catch (ClassNotFoundException | SQLException e) {
    	   			// TODO Auto-generated catch block
    	   			e.printStackTrace();
    	   		}
    	           RoomTotal roomtotal = new RoomTotal(0,roomlist.size(), roomlist);  
    	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
    	           Gson gson2 = new Gson();  
    	           String json = gson2.toJson(roomtotal);  
    	           pk.getpack(json, response);
    	           return ;
    		
    	}
    	
    	SensorService sensorservice =new SensorService ();
    	SensorModel s = null;
		try {
			s = sensorservice.querySensor(t.HID+"");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<BIDandRID>  info = new ArrayList<BIDandRID>();	
		System.out.println("SSS:"+s.RID);
		BIDandRID br=new BIDandRID(s.getBID(),s.getRID());
        info.add(br);
		outputroom output = new outputroom(0,info);  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
    }
    private void server_room2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String l;
    	l="L1";
    	l=request.getParameter("LID");
    	System.out.println("DEF:"+l);
    	RoomService roomservice =new RoomService ();  
    	if(l.equals("0")) {
    		System.out.println("ZZZZ");
    	    	List<RoomModel> roomlist = new ArrayList<RoomModel>(); 
    	           try {
    	   			roomlist= roomservice.listAllRooms();
    	   		} catch (ClassNotFoundException | SQLException e) {
    	   			// TODO Auto-generated catch block
    	   			e.printStackTrace();
    	   		}
    	           RoomTotal roomtotal = new RoomTotal(0,roomlist.size(), roomlist);  
    	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
    	           Gson gson2 = new Gson();  
    	           String json = gson2.toJson(roomtotal);  
    	           pk.getpack(json, response);
    	           return ;
    		
    	}
    	
    	LightService lightservice =new LightService ();
    	LightModel s = null;
		try {
			s = lightservice.queryLight(l+"");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<BIDandRID>  info = new ArrayList<BIDandRID>();	
		System.out.println("SSS:"+s.RID);
		BIDandRID br=new BIDandRID(s.getBID(),s.getRID());
        info.add(br);
		outputroom output = new outputroom(0,info);  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
    }
    private void server_userInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Gson gson = new Gson();
    	inputuserInfo t=new inputuserInfo();
    	t.UID=Integer.parseInt(request.getParameter("UID"));
    	ClientService clientservice =new ClientService ();
    	ClientModel s = null;
		try {
			s = clientservice.queryClient(t.UID);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		outputuserInfo output = new outputuserInfo(0,s.getUID(),s.getName(),s.getRole());  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
        
    }
    
    private void server_hardwareInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int st=0;
    	inputhardwareInfo t=new inputhardwareInfo();
    	t.HID=request.getParameter("HID");
    	System.out.println("T:"+t.HID);
    	SensorService sensorservice =new SensorService ();
    	SensorModel s = null;
		try {
			s = sensorservice.querySensor(t.HID+"");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(s.SID.equals("-1")) {st=1;}
		System.out.println("SSS:"+s.SID);
   
		outputhardwareinfo output = new outputhardwareinfo(st,s.getBID(),s.getRID(),s.getSID(),s.gettype(),1);  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
    }
    private void server_deviceInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int st=0;
    	String l=request.getParameter("LID");
    	System.out.println("T:"+l);
    	LightService lightservice =new LightService ();
    	LightModel s = null;
		try {
			s =lightservice.queryLight(l+"");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			st=1;
			e.printStackTrace();
		}
		if(s.LID.equals("-1")) {st=1;}
		System.out.println("SSS:"+s.LID);
        
		outputdeviceinfo output = new outputdeviceinfo(st,s.getBID(),s.getRID(),s.getLID(),s.getSetTime());  
        
        // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
        Gson gson2 = new Gson();  
        String json = gson2.toJson(output);  
        pk.getpack(json, response);
    }
  private void user_client (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	ClientService clientservice =new ClientService ();  
    	int option=Integer.parseInt(request.getParameter("option"));
    	 System.out.println("option:"+option);
    	System.out.println(option);
    	if(option==0) {
	    	List<ClientModel> clientlist = new ArrayList<ClientModel>(); 
	           try {
	   			clientlist= (List<ClientModel>) clientservice.listAllAccounts();
	   		} catch (ClassNotFoundException | SQLException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
	   
	        
	           //BuildingTotal buildingtotal = new BuildingTotal(0,clientlist.size(), clientlist);  
	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
	           Gson gson2 = new Gson();  
	         //  String json = gson2.toJson(buildingtotal);  
	         //  pk.getpack(json, response);
    	}
    	else if(option == 1)
    	{
    		int UID=Integer.parseInt(request.getParameter("UID"));
    		String name=request.getParameter("nickname");
    		String password=request.getParameter("password");
    		int role = Integer.parseInt(request.getParameter("role"));
    		int status=-1;
    		 try {
 	   			status= clientservice.addaccount(UID,name,password,role);
 	   		} catch (ClassNotFoundException | SQLException e) {
 	   			// TODO Auto-generated catch block
 	   			e.printStackTrace();
 	   		}
    		success suc = null;
 	        if(status==0) 
 	        {
 	        	suc = new success(0,"Add successfully.");
 	        }
 	        else if(status == 1)
 	        {
 	        	suc = new success(1, "No permission.");
 	        }
 	       else if(status == 2)
	        {
	        	suc = new success(2, "The UID number already exists.");
	        }
 	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
 	        Gson gson2 = new Gson();  
 	        String json = gson2.toJson(suc);  
 	        pk.getpack(json, response);
    	}
    	
    }
    private void user_room (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	RoomService roomservice =new RoomService ();  
    	int option=Integer.parseInt(request.getParameter("option"));
    	if(option==0) {
    		int BID=1;
   		 	BID=Integer.parseInt(request.getParameter("BID"));
	    	List<RoomModel> roomlist = new ArrayList<RoomModel>(); 
	           try {
	   			roomlist= roomservice.queryRoomInABuilding(BID);
	   		} catch (ClassNotFoundException | SQLException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
	   
	        
	           RoomTotal roomtotal = new RoomTotal(0,roomlist.size(), roomlist);  
	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
	           Gson gson2 = new Gson();  
	           String json = gson2.toJson(roomtotal);  
	           pk.getpack(json, response);
    	}
    	else if(option == 1)
    	{
    		int BID=1;
    		 BID=Integer.parseInt(request.getParameter("BID"));
    		int status=-1;
    		 try {
 	   			status= roomservice.addRoom(BID);
 	   			System.out.println(status);
 	   		} catch (ClassNotFoundException | SQLException e) {
 	   			// TODO Auto-generated catch block
 	   			e.printStackTrace();
 	   		}
    		success suc = null;
 	        if(status==0) 
 	        {
 	        	suc = new success(0,"Add successfully.");
 	        }
 	        else if(status == 1)
 	        {
 	        	suc = new success(1, "No permission.");
 	        }
 	       else if(status == 2)
	        {
	        	suc = new success(2, "The building does not exist.");
	        }
 	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
 	        Gson gson2 = new Gson();  
 	        String json = gson2.toJson(suc);  
 	        pk.getpack(json, response);
    	}
    	else if(option == 2)
    	{
    		int BID=3;
    		int RID=2;
    		 BID=Integer.parseInt(request.getParameter("BID"));
    		 RID=Integer.parseInt(request.getParameter("RID"));
    		
    		int status=-1;
    		 try {
 	   			status= roomservice.deleteRoom(BID, RID);
 	   		} catch (ClassNotFoundException | SQLException e) {
 	   			// TODO Auto-generated catch block
 	   			e.printStackTrace();
 	   		}
    		 System.out.println(status);
    		success suc = null;
 	        if(status==0) 
 	        {
 	        	suc = new success(0,"Delete successfully.");
 	        }
 	        else if(status == 1)
 	        {
 	        	suc = new success(1, "No permission.");
 	        }
 	       else if(status == 2)
	        {
	        	suc = new success(2, "The building doesn't exist.");
	        }
 	      else if(status == 3)
	        {
	        	suc = new success(3, "The room doesn't exist.");
	        }
 	     else if(status == 4)
	        {
	        	suc = new success(3, "other problem.");
	        }
 	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
 	        Gson gson2 = new Gson();  
 	        String json = gson2.toJson(suc);  
 	        pk.getpack(json, response);
    	}
    }
    
private void user_building (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	BuildingService buildingservice =new BuildingService ();  
    	int option=Integer.parseInt(request.getParameter("option"));
    	 System.out.println("option:"+option);
    	System.out.println(option);
    	if(option==0) {
	    	List<BuildingModel> buildinglist = new ArrayList<BuildingModel>(); 
	           try {
	   			buildinglist= buildingservice.listAllBuildings();
	   		} catch (ClassNotFoundException | SQLException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
	   
	        
	           BuildingTotal buildingtotal = new BuildingTotal(0,buildinglist.size(), buildinglist);  
	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
	           Gson gson2 = new Gson();  
	           String json = gson2.toJson(buildingtotal);  
	           pk.getpack(json, response);
    	}
    	else if(option == 1)
    	{
    		String BName=request.getParameter("BName");
    		int status=-1;
    		 try {
 	   			status= buildingservice.addBuilding(BName);
 	   		} catch (ClassNotFoundException | SQLException e) {
 	   			// TODO Auto-generated catch block
 	   			e.printStackTrace();
 	   		}
    		success suc = null;
 	        if(status==0) 
 	        {
 	        	suc = new success(0,"Add successfully.");
 	        }
 	        else if(status == 1)
 	        {
 	        	suc = new success(1, "No permission.");
 	        }
 	       else if(status == 2)
	        {
	        	suc = new success(2, "The building number already exists.");
	        }
 	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
 	        Gson gson2 = new Gson();  
 	        String json = gson2.toJson(suc);  
 	        pk.getpack(json, response);
    	}
    	else if(option == 2)
    	{
    		int BID=Integer.parseInt(request.getParameter("BID"));
    		int status=-1;
    		 try {
 	   			status= buildingservice.deleteBuilding(BID);
 	   		} catch (ClassNotFoundException | SQLException e) {
 	   			// TODO Auto-generated catch block
 	   			e.printStackTrace();
 	   		}
    		success suc = null;
 	        if(status==0) 
 	        {
 	        	suc = new success(0,"Delete successfully.");
 	        }
 	        else if(status == 1)
 	        {
 	        	suc = new success(1, "No permission.");
 	        }
 	       else if(status == 2)
	        {
	        	suc = new success(2, "The building doesn't exist.");
	        }
 	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
 	        Gson gson2 = new Gson();  
 	        String json = gson2.toJson(suc);  
 	        pk.getpack(json, response);
    	}
    }
    private void user_light (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
    	LightService lightservice =new LightService ();  
    	
    	int option=Integer.parseInt(request.getParameter("option"));
    	if(option==0) {
    		int BID=Integer.parseInt(request.getParameter("BID"));
    		int RID=Integer.parseInt(request.getParameter("RID"));
	    	List<LightModel> lightlist = new ArrayList<LightModel>(); 
	           try {
	        	   lightlist= lightservice.queryLightInARoom(BID,RID);
	   		} catch (ClassNotFoundException | SQLException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
	           LightTotal lighttotal = new LightTotal(0,lightlist.size(),lightlist);  
	     
	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
	           Gson gson2 = new Gson();  
	           String json = gson2.toJson(lighttotal);  
	           pk.getpack(json, response);
    	}
    	else if(option==1) {//����
    		int bid=Integer.parseInt(request.getParameter("BID"));
    		int rid=Integer.parseInt(request.getParameter("RID"));
    		String lid=request.getParameter("LID");
    		String st=request.getParameter("setTime");
    		LightService ls=new LightService();
    		int flag=ls.addLight(bid, rid, lid, st);
    		if (flag==0) {
    			success flag0=new success(0,"add success");
    			 Gson gson0 = new Gson();  
    			 String json = gson0.toJson(flag0);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==1) {
    			success flag1=new success(1,"failed!no permission");
    			 Gson gson1 = new Gson();  
    			 String json = gson1.toJson(flag1);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==2) {
    			success flag2=new success(2,"failed!Building do not exist");
    			 Gson gson2 = new Gson();  
    			 String json = gson2.toJson(flag2);  
  	           	 pk.getpack(json, response);
    		}
    		else if (flag==3) {
    			success flag3=new success(3,"failed!Room do not exist");
    			 Gson gson3 = new Gson();  
    			 String json = gson3.toJson(flag3);  
  	            	pk.getpack(json, response);
    		} 
    		else if (flag==4) {
    			success flag4=new success(4,"failed!The Light has already exist.");
    			 Gson gson4 = new Gson();  
    			 String json = gson4.toJson(flag4);  
  	            	pk.getpack(json, response);
    		}
    		
    	}
    	else if(option==2) {//delete
    		int bid=Integer.parseInt(request.getParameter("BID"));
    		int rid=Integer.parseInt(request.getParameter("RID"));
    		String lid=request.getParameter("LID");
    		LightService ls=new LightService();
    		int flag=ls.deleteLight(bid, rid, lid);
    		if (flag==0) {
    			success flag0=new success(0,"delete success");
    			 Gson gson0 = new Gson();  
    			 String json = gson0.toJson(flag0);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==1) {
    			success flag1=new success(1,"failed!no permission");
    			 Gson gson1 = new Gson();  
    			 String json = gson1.toJson(flag1);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==2) {
    			success flag2=new success(2,"failed!Building do not exist");
    			 Gson gson2 = new Gson();  
    			 String json = gson2.toJson(flag2);  
  	           	 pk.getpack(json, response);
    		}
    		else if (flag==3) {
    			success flag3=new success(3,"failed!Room do not exist");
    			 Gson gson3 = new Gson();  
    			 String json = gson3.toJson(flag3);  
  	            	pk.getpack(json, response);
    		} 
    		else if (flag==4) {
    			success flag4=new success(4,"failed!Light do not exist.");
    			 Gson gson4 = new Gson();  
    			 String json = gson4.toJson(flag4);  
  	             pk.getpack(json, response);
    		}
    		else if (flag==5) {
    			success flag5=new success(5,"failed!");
    			 Gson gson5 = new Gson();  
    			 String json = gson5.toJson(flag5);  
  	             pk.getpack(json, response);
    		}
    	}
    }
    private void user_sensor (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
    	SensorService sensorservice =new SensorService ();  
    	
    	int option=Integer.parseInt(request.getParameter("option"));
    	if(option==0) {
	    	List<SensorModel> sensorlist = new ArrayList<SensorModel>(); 
	           try {
	        	   sensorlist= sensorservice.querySensorInARoom(3,1);
	   		} catch (ClassNotFoundException | SQLException e) {
	   			// TODO Auto-generated catch block
	   			e.printStackTrace();
	   		}
	           SensorTotal sensortotal = new SensorTotal(0,sensorlist.size(), sensorlist);  
	     
	           // ����GSON jar���߰���װ�õ�toJson��������ֱ������JSON�ַ���  
	           Gson gson2 = new Gson();  
	           String json = gson2.toJson(sensortotal);  
	           pk.getpack(json, response);
    	}
    	else if(option==1) {
    		int bid=Integer.parseInt(request.getParameter("BID"));
    		int rid=Integer.parseInt(request.getParameter("RID"));
    		String sid=request.getParameter("SID");
    		int ty=Integer.parseInt(request.getParameter("type"));
    		System.out.println("BID:"+bid);
    		System.out.println("RID:"+rid);
    		System.out.println("SID:"+sid);
    		System.out.println("type:"+ty);
    		SensorService ls=new SensorService();
    		int flag=ls.addSensor(bid, rid, sid, ty);
    		if (flag==0) {
    			success flag0=new success(0,"add success");
    			 Gson gson0 = new Gson();  
    			 String json = gson0.toJson(flag0);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==1) {
    			success flag1=new success(1,"failed!no permission");
    			 Gson gson1 = new Gson();  
    			 String json = gson1.toJson(flag1);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==2) {
    			success flag2=new success(2,"failed!Building do not exist");
    			 Gson gson2 = new Gson();  
    			 String json = gson2.toJson(flag2);  
  	           	 pk.getpack(json, response);
    		}
    		else if (flag==3) {
    			success flag3=new success(3,"failed!Room do not exist");
    			 Gson gson3 = new Gson();  
    			 String json = gson3.toJson(flag3);  
  	            	pk.getpack(json, response);
    		} 
    		else if (flag==4) {
    			success flag4=new success(4,"failed!The Sensor has already exist.");
    			 Gson gson4 = new Gson();  
    			 String json = gson4.toJson(flag4);  
  	            	pk.getpack(json, response);
    		}
    		
    	}
    	else if(option==2) {
    		int bid=Integer.parseInt(request.getParameter("BID"));
    		int rid=Integer.parseInt(request.getParameter("RID"));
    		String sid=request.getParameter("SID");
    		System.out.println("option2\n");
    		System.out.println("BID:"+bid);
    		System.out.println("RID:"+rid);
    		System.out.println("SID:"+sid);
    		SensorService ls=new SensorService();
    		int flag=ls.deleteSensor(bid, rid, sid);
    		if (flag==0) {
    			success flag0=new success(0,"del success");
    			 Gson gson0 = new Gson();  
    			 String json = gson0.toJson(flag0);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==1) {
    			success flag1=new success(1,"failed!no permission");
    			 Gson gson1 = new Gson();  
    			 String json = gson1.toJson(flag1);  
  	           	pk.getpack(json, response);
    		}
    		else if (flag==2) {
    			success flag2=new success(2,"failed!Building do not exist");
    			 Gson gson2 = new Gson();  
    			 String json = gson2.toJson(flag2);  
  	           	 pk.getpack(json, response);
    		}
    		else if (flag==3) {
    			success flag3=new success(3,"failed!Room do not exist");
    			 Gson gson3 = new Gson();  
    			 String json = gson3.toJson(flag3);  
  	            	pk.getpack(json, response);
    		} 
    		else if (flag==4) {
    			success flag4=new success(4,"failed!Sensor do not exist");
    			 Gson gson4 = new Gson();  
    			 String json = gson4.toJson(flag4);  
  	            	pk.getpack(json, response);
    		}
    		else if (flag==5) {
    			success flag5=new success(5,"failed!");
    			 Gson gson5 = new Gson();  
    			 String json = gson5.toJson(flag5);  
  	             pk.getpack(json, response);
    		}
    		
    	}
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	 // ��ȡ�����URI��ַ��Ϣ
        String url = request.getRequestURI();
       // JOptionPane.showMessageDialog(null, url,"����",  JOptionPane.ERROR_MESSAGE);
        // ��ȡ���еķ�����
        int number=url.lastIndexOf("/")+1;
        String methodName = url.substring(number,url.length());
        methodName2=methodName;
        Method method = null;
        //JOptionPane.showMessageDialog(null,  methodName,"����", JOptionPane.ERROR_MESSAGE);
        
        try {
            // ʹ�÷�����ƻ�ȡ�ڱ����������˵ķ���
            method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class, HttpServletResponse.class);
            // ִ�з���
            method.invoke(this, request, response);
        } catch (Exception e) {
        	System.out.println(e.getMessage());
            throw new RuntimeException("���÷���������");
        }  
    	 
    }
}

