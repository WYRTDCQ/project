package com.test.model;

import java.util.List;

public class ClientTotal {
		int status;//�ɹ���־
	 	private int total; //��������  
	    private List<ClientModel> info; //�����б� 
	   
	    public ClientTotal(int status,int total, List<ClientModel> info) {  
	        this.total = total;  
	        this.info = info;  
	    }  
	    public int getTotal() {  
	        return total;  
	    }  
	    public void setTotal(int total) {  
	        this.total = total;  
	    }  
	    public List<ClientModel> getRows() {  
	        return info;
	    }  
	    public void setRows(List<ClientModel> rows) {  
	        this.info = info;;  
	    }  
	      
}
