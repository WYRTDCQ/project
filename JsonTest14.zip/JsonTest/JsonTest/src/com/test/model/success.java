package com.test.model;

public class success {
	int status;
	String msg;
	public success(int status,String msg) {
		this.status=status;
		this.msg=msg;
	}
}
