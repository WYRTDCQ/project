package com.test.model;

import java.util.List;

public class BuildingTotal {
		int status;//�ɹ���־
	 	private int total; //
	    private List<BuildingModel> info; // 
	    
	    public BuildingTotal() {  
	    }  
	    public BuildingTotal(int status,int total, List<BuildingModel> rows) {  
	        this.total = total;  
	        this.info = rows;  
	    }  
	    public int getTotal() {  
	        return total;  
	    }  
	    public void setTotal(int total) {  
	        this.total = total;  
	    }  
	    public List<BuildingModel> getRows() {  
	        return info;  
	    }  
	    public void setRows(List<BuildingModel> rows) {  
	        this.info = rows;  
	    }  
	      
}
