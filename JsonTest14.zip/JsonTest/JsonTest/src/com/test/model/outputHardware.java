package com.test.model;

import java.util.List;
public class outputHardware {
		int status;//�ɹ���־
		List<String> info;
	   
	    public outputHardware(int status,List<String> info) {  
	        this.status = status;  
	        this.info = info;  
	    }  
	      
}
