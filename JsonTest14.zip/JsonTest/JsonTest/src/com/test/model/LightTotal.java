package com.test.model;



import java.util.List;  

public class LightTotal {  
	int status;//�ɹ���־
	private int total; //��������  
    private List<LightModel> info; //�����б�  
 
      
    public LightTotal() {  
    }  
    public LightTotal(int status,int total, List<LightModel> rows) {  
        this.total = total;  
        this.info = rows;  
    }  
    public int getTotal() {  
        return total;  
    }  
    public void setTotal(int total) {  
        this.total = total;  
    }  
    public List<LightModel> getRows() {  
        return info;  
    }  
    public void setRows(List<LightModel> rows) {  
        this.info = rows;  
    }  
      
      
}  