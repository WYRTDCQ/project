package com.test.model;

public class inputhardwareInfo {
	public String HID;
	String getHID() {
		return HID;
	}
}
