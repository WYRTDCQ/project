package com.test.model;

import java.util.List;
public class outputhardwareinfo{
		int status;
		int BID;
		int RID;
		String HID;
	 	
	 	String nickname;
	 	int type; 
	 	int ctrl;
	 	

		public  outputhardwareinfo(int status,int BID,int RID,String HID,int type,int ctrl) {  
	        this.status = status;  
	        this.BID = BID;
	        this.RID = RID;
	        this.HID = HID;
	        this.nickname = "hello";
	        this.type = type;
	        this.ctrl = ctrl;
	    }  
	      
}
