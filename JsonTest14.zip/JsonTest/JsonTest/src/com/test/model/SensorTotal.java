package com.test.model;

import java.util.List;

public class SensorTotal {
		int status;//�ɹ���־
	 	private int total; //��������  
	    private List<SensorModel> info; //�����б� 
	    public SensorTotal() {  
	    }  
	    public SensorTotal(int status,int total, List<SensorModel> rows) {  
	        this.total = total;  
	        this.info = rows;  
	    }  
	    public int getTotal() {  
	        return total;  
	    }  
	    public void setTotal(int total) {  
	        this.total = total;  
	    }  
	    public List<SensorModel> getRows() {  
	        return info;  
	    }  
	    public void setRows(List<SensorModel> rows) {  
	        this.info = rows;  
	    }  
	      
}
