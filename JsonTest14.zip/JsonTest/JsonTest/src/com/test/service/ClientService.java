package com.test.service;

import com.test.dao.ClientDao;

import java.sql.SQLException;
import java.util.List;

import com.test.model.BuildingModel;
import com.test.model.ClientModel;
public class ClientService {
	private ClientDao cdao=new ClientDao();
	public ClientModel queryClient(int UID) throws ClassNotFoundException, SQLException
	{
		List<ClientModel> list=(List<ClientModel>)cdao.select(UID);	
		ClientModel onemodel=list.get(0);
		return onemodel;
	}
	public int addaccount(int ID,String name,String password,int role) throws ClassNotFoundException, SQLException {
		ClientModel  onemodel=new ClientModel();
		onemodel.setUID(ID);
		onemodel.setName(name);
		onemodel.setPassword(password);
		onemodel.setRole(role);
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			cdao.insert(onemodel);
			return 0;//success
		}
		else {
			return 2;//用户不存在
		}
	}
	
	public int deleteaccount(int ID) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//用户不存在
		}
		else {
			cdao.delete(ID);
			return 0;//成功
		}
	}
	public int changepassword(int ID,String password) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//用户不存在
		}
		ClientModel onemodel=list.get(0);
		onemodel.setPassword(password);
		cdao.update(onemodel);
		return 0;//success
		
	}
	public int loginAuthentication(int ID,String password) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//用户不存在
		}
		ClientModel onemodel=list.get(0);
		if(onemodel.getPassword().equals(password)) {
			return 0;//success
		}
		else {
			return 1;//密码不正确
		}
	}
	public int changeUserRole(int ID,int Role) throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.select(ID);
		if(list.size()==0) {
			return 2;//用户不存在
		}
		ClientModel onemodel=list.get(0);
		onemodel.setRole(Role);
		cdao.update(onemodel);
	    return 0;//success
	}
	public Object listAllAccounts() throws ClassNotFoundException, SQLException {
		List<ClientModel> list=(List<ClientModel>)cdao.selectAll();
		return list;
	}
	
}
