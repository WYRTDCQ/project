package com.test.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.test.dao.SensorDao;
import com.test.model.LightModel;
import com.test.model.SensorModel;

public class SensorService {
		private int sensorNum;
		SensorDao sd= new SensorDao();
		public SensorModel querySensor(String SID) throws ClassNotFoundException, SQLException
		{
			System.out.println("SD:"+SID);
			return sd.query(SID);
		}
		public int addSensor(int BID,int RID,String SID,int type) throws ClassNotFoundException, SQLException
		{
			if(sd.existBID(BID)== false) //BID������
				return 2;
			if(sd.existRID(BID, RID)==false) //RID������
				return 3;
			
			if(sd.insert(BID, RID, SID, type))
				return 0;
			return 4;
		}
		public int deleteSensor(int BID, int RID,String SID) throws ClassNotFoundException, SQLException
		{
			if(sd.existBID(BID) == false)//BID������
				return 2;
			if(sd.existRID(BID, RID) == false)//RID������
				return 3;
			if(sd.existSID(BID, RID,SID) == false)//SID������
				return 4;
			if(sd.delete(BID, RID,SID))
				return 0;
			return 5;//ɾ�����ɹ�������ԭ��
		}
		public ArrayList<SensorModel> querySensorInARoom(int BID,int RID) throws ClassNotFoundException, SQLException
		{
			ArrayList<SensorModel> list = new ArrayList<SensorModel>();
			list = sd.query(BID,RID);
			if(list.isEmpty()) {//����Ϊ��
				//setSensorNum(0);
				//return null;
			}
			list =sd.query(BID,RID);
			setSensorNum(list.size());
			return list;
		}
		public int getSensorNum() {
			return sensorNum;
		}
		public void setSensorNum(int sensorNum) {
			this.sensorNum = sensorNum;
		}
}
