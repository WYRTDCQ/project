package com.test.service;


import java.sql.SQLException;
import java.util.ArrayList;

import com.test.dao.BuildingDao;
import com.test.model.BuildingModel;

public class BuildingService {
	private BuildingDao bd = new BuildingDao();
	private int buildingNum = 0;
	
	public BuildingModel queryBuilding(int BID) throws ClassNotFoundException, SQLException
	{
		if(bd.existBID(BID) == false)//BID������
			return null;
		return bd.query(BID);
		
	}
	public int addBuilding(String BName) throws ClassNotFoundException, SQLException
	{
		int bid = bd.maxBID() + 1;
		if(bd.existBID(bid))//BID�ظ�
			return 2;
		if(bd.insert(bid, BName))
			return 0;
		return 3;
	}
	public int deleteBuilding(int BID) throws ClassNotFoundException, SQLException
	{
		if(bd.existBID(BID) == false)//BID������
			return 2;
		if(bd.delete(BID))
			return 0;
		return 3;
	}
	@SuppressWarnings("null")
	public ArrayList<BuildingModel> listAllBuildings() throws ClassNotFoundException, SQLException
	{
		ArrayList<BuildingModel> list = new ArrayList<BuildingModel>();
		list = bd.list();
		if(list.isEmpty()) {//����Ϊ��
			setBuildingNum(0);
			return null;
		}
		list =bd.list();
		setBuildingNum(list.size());
		return list;
	}
	public int getBuildingNum() {
		return buildingNum;
	}
	public void setBuildingNum(int buildingNum) {
		this.buildingNum = buildingNum;
	}
}
