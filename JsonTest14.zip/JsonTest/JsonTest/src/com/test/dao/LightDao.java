package com.test.dao;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import com.test.model.*;
import tools.ConnectionFactory;



import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Statement;

import com.test.model.LightModel;


public class LightDao {
	//��building����BID�Ƿ����
	public LightModel query(String LID) throws ClassNotFoundException, SQLException
	{
		System.out.println("LID:"+LID);
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
	    ResultSet rs = null;
		LightModel l = new LightModel();
		String sql="select * from light ;";
	    rs = statement.executeQuery(sql);
	    System.out.println("GREAT");
	    LightModel lm =new LightModel();
	    lm.setLID("-1");
	    while(rs.next())
	    {
	    	
	    	int BID=Integer.parseInt(rs.getString("BID"));
	    	int RID=Integer.parseInt(rs.getString("RID"));
		    
	    	String lid = rs.getString("LID");
	    	String setTime = rs.getString("setTime");
	    	
	    	lm.setBID(BID);
	    	lm.setRID(RID);
	    	lm.setSetTime(setTime);
	    	if(lid.equals(LID)) {
	    		lm.setLID(lid);
	    		break;
	    	}
	    	
	    }
	    System.out.println("LID:"+lm.LID);
	    connection.closeConnection(statement, con);
	    return lm;
	}	
	public boolean existBID(int BID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		String sql="select BID from building where BID="+BID+";";
	    ResultSet rs = statement.executeQuery(sql);
	    boolean flag;
	    if(rs.next() == false)//BID���ظ�
	    	flag= false;
	    else
	    	flag=true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	//�ڷ�������RID�Ƿ����
	public boolean existRID(int BID,int RID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		String sql="select BID,RID from room where BID="+BID+" and RID="+RID+" ;";
	    ResultSet rs = statement.executeQuery(sql);
	    boolean flag;
	    if(rs.next() == false)//RID���ظ�
	    	flag= false;
	    else
	    	flag=true;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	//��light�����LID�Ƿ����
	public boolean existLID(int BID,int RID,String LID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		String sql="select BID,RID,LID from light where BID="+BID+" and RID="+RID+" and LID=\""+LID+"\";";
	    ResultSet rs = statement.executeQuery(sql);
	    boolean flag;
	    if(rs.next() == false)//LID���ظ�
	    	flag= false;
	    else
	    	flag=true;
	    connection.closeConnection(statement, con);
	    return flag;
	}	
	public int countAll() throws ClassNotFoundException, SQLException
	{
		int result;
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
	    String sql="select count(*) from light;";
	    rs = statement.executeQuery(sql);
	    if(rs.next() == false)
	    	result= 0;
	    else
	    	result= rs.getInt(1);
	    connection.closeConnection(statement, con);
	    return result;
	}
	public boolean insert(int BID,int RID,String LID,String setTime) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		int result=0;
		boolean flag;
	    String sql="insert into light values("+BID+","+RID+",\""+LID+"\",\""+setTime+"\");";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag=true;
	    else
	    	flag=false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	public boolean delete(int BID,int RID,String LID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		int result=0;
		boolean flag;
	    String sql="delete from light where BID="+BID+" and RID="+RID+" and LID=\""+LID+"\";";
	    result = statement.executeUpdate(sql);
	    if(result == 1)//���ӳɹ�
	    	flag=true;
	    else
	    	flag=false;
	    connection.closeConnection(statement, con);
	    return flag;
	}
	
	@SuppressWarnings("null")
	//��ô���صƵ�״̬����Ŀ������û�м�¼
	public ArrayList<LightModel> query(int BID,int RID) throws ClassNotFoundException, SQLException
	{
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ArrayList<LightModel> list = new ArrayList<LightModel>();
	    String sql="select * from light where BID="+BID+" and RID="+RID+";";
	    rs = statement.executeQuery(sql);
	    while(rs.next())
	    {
	    	String lid = rs.getString("LID");
	    	String setTime = rs.getString("setTime");
	    	LightModel lm = new LightModel();
	    	lm.setBID(BID);
	    	lm.setRID(RID);
	    	lm.setLID(lid);
	    	lm.setSetTime(setTime);
	    	list.add(lm);
	    }
	    connection.closeConnection(statement, con);
	    return list;
	}
}

