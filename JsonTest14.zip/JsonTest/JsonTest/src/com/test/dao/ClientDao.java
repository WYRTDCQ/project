package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;
import com.test.model.*;
import tools.ConnectionFactory;
public class ClientDao {
	public ConnectionFactory dTools=new ConnectionFactory();
	private	ResultSet rs;
	public static String thename="root";
	public static String thepassword="root";
	
	public ClientModel query(int UID) throws ClassNotFoundException, SQLException
	{
		boolean flag;
		Connection con = dTools.getConnection(thename, thepassword);
		Statement statement = (Statement) con.createStatement();
		ResultSet rs = null;
		ClientModel l = new ClientModel();
	    String sql="select* from client where UID="+UID+";";
	    rs = statement.executeQuery(sql);
	    dTools.closeConnection();
    	return l;
	}
	public boolean insert(Object model) throws ClassNotFoundException, SQLException {
		ClientModel model0;
	    String  sql ="insert into client(UId,name,password,role) values(?,?,?,?)";
		Connection con=dTools.getConnection(thename, thepassword);
		PreparedStatement pstmt =con.prepareStatement(sql);
		model0=(ClientModel)model;
		try {
		pstmt.setInt(1,model0.getUID());
		pstmt.setString(2,model0.getName() );
		pstmt.setString(3,model0.getPassword() );
		pstmt.setInt(4, model0.getRole());
		pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return false;
		}
		dTools.closeConnection();
		return true;
	}
	public boolean delete(int id) throws ClassNotFoundException, SQLException {
		String sql ="delete from client where UId=?";
		Connection con=dTools.getConnection(thename, thepassword);
		PreparedStatement pstmt =con.prepareStatement(sql);
		try {
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			return false;
		} 
		dTools.closeConnection();
		return true;
	}
/*	public boolean queryPassword(String password) throws ClassNotFoundException, SQLException {
		ConnectionFactory connection=new ConnectionFactory();
		Connection con = connection.getConnection("root", "root");
		Statement statement = (Statement) con.createStatement();
		ResultSet result=null;
		boolean flag;
	    String sql="select password from client where password=MD5(\""+password+"helloworld"+"\");";
	    result = statement.executeQuery(sql);
	    if(result.next() == true)//���ӳɹ�
	    	flag=true;
	    else
	    	flag=false;
	    connection.closeConnection(statement, con);
	    return flag;
	}*/
	public boolean update(Object model) throws ClassNotFoundException, SQLException {
		ClientModel model0;
		model0=(ClientModel)model;
		this.delete(model0.getUID());
		this.insert(model0);
		return true;
	}
	public Object select(int ID) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String sql;
		sql=new String("select * from client where UId=?");
		Connection con=dTools.getConnection(thename, thepassword);
		PreparedStatement pstmt =con.prepareStatement(sql);
			try {
				pstmt.setInt(1,ID);
				rs=pstmt.executeQuery();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  List<ClientModel> list=convert(rs);
		  dTools.closeConnection();
		  return list;
	}
	
	public Object selectAll() throws ClassNotFoundException, SQLException {
		String sql="select * from client";
		Connection con=dTools.getConnection(thename, thepassword);
		PreparedStatement pstmt =con.prepareStatement(sql);
		try {
			rs=pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		List<ClientModel> list=convert(rs);//����ת��
		dTools.closeConnection();
		return list;
	}
	private static List<ClientModel> convert(ResultSet rs)
	{
		
		List<ClientModel> list=new ArrayList<ClientModel>();
		ClientModel model;
		try {
			while(rs.next())//���ζ�ȡRS���������model�ٴ���List
			{
				model=new ClientModel();
				model.setUID(rs.getInt("UID"));
				model.setName(rs.getString("name"));
				model.setPassword(rs.getString("password"));
			
				model.setRole(rs.getInt("role"));
				list.add(model);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
		
	}

}
